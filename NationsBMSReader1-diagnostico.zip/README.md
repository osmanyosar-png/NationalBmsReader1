# Nations BMS Reader — diagnóstico BLE (siguiente versión)

Esta versión parte del proyecto anterior que ya conecta con el BMS. Añade entrada manual de tramas hexadecimales, envío único, registro TX/RX y estado de confirmación del descriptor CCCD.

## Datos conocidos
- BMS observado: `BMS-508281060400331D`
- Dirección BLE observada: `53:62:10:0C:32:38`
- Servicio esperado: `00002760-08c2-11e1-9073-0e8ac72e1001`
- El proyecto no inventa ni calcula SOC: hace falta validar una respuesta real y su formato.
- Las tramas de prueba se conservan como referencias, pero su formato/protocolo no se da por confirmado.

## Compilar
GitHub Actions debe ejecutar `gradle assembleDebug` con Java 17, Gradle 8.9 y Android SDK 35. El APK se publica como artefacto `NationsBMSReader-APK`.
