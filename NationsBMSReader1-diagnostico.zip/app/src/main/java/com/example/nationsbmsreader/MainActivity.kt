package com.example.nationsbmsreader

import android.Manifest
import android.app.Activity
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*
import java.util.UUID

class MainActivity : Activity() {
    private val serviceId = UUID.fromString("00002760-08c2-11e1-9073-0e8ac72e1001")
    private val cccdId = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    private val knownAddress = "53:62:10:0C:32:38"
    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var commandInput: EditText
    private lateinit var adapter: BluetoothAdapter
    private var scanner: BluetoothLeScanner? = null
    private var gatt: BluetoothGatt? = null
    private var target: BluetoothDevice? = null
    private var notifyChar: BluetoothGattCharacteristic? = null
    private var writeChar: BluetoothGattCharacteristic? = null
    private var cccdReady = false

    private fun say(s: String) {
        runOnUiThread {
            status.text = s
            log.append("\n$s")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        layout.addView(TextView(this).apply {
            text = "Nations BMS Reader — diagnóstico BLE"
            textSize = 21f
        })
        status = TextView(this).apply {
            text = "Listo. Activa Bluetooth y pulsa Buscar."
            textSize = 15f
        }
        layout.addView(status)
        layout.addView(Button(this).apply {
            text = "1. Buscar BMS"
            setOnClickListener { requestBlePermissions() }
        })
        layout.addView(Button(this).apply {
            text = "2. Conectar"
            setOnClickListener {
                val d = target
                if (d == null) say("No hay BMS seleccionado. Pulsa Buscar.") else {
                    say("Conectando a ${d.address}…")
                    try { gatt?.close() } catch (_: Exception) {}
                    cccdReady = false
                    notifyChar = null
                    writeChar = null
                    try {
                        gatt = d.connectGatt(this@MainActivity, false, callback, BluetoothDevice.TRANSPORT_LE)
                    } catch (e: Exception) {
                        say("Error conectando: ${e.message}")
                    }
                }
            }
        })
        layout.addView(TextView(this).apply { text = "Trama hexadecimal (separada por espacios):" })
        commandInput = EditText(this).apply {
            setSingleLine(true)
            textSize = 16f
            setText("DB DB 01 03 00 00 00 01 04")
            hint = "Ej.: DB DB 01 03 ..."
        }
        layout.addView(commandInput)
        layout.addView(Button(this).apply {
            text = "ENVIAR UNA VEZ"
            setOnClickListener {
                val bytes = parseHex(commandInput.text.toString())
                if (bytes == null || bytes.isEmpty()) {
                    say("Trama inválida. Escribe bytes hexadecimales, por ejemplo: DB DB 01 03")
                } else {
                    send(bytes)
                }
            }
        })
        layout.addView(Button(this).apply {
            text = "Usar consulta de identificación conocida"
            setOnClickListener { commandInput.setText("DB DB 03 03 00 00 00 03 06") }
        })
        layout.addView(Button(this).apply {
            text = "Usar consulta de prueba anterior"
            setOnClickListener { commandInput.setText("DB DB 01 03 00 00 00 01 04") }
        })
        layout.addView(Button(this).apply {
            text = "Desconectar"
            setOnClickListener {
                try { gatt?.disconnect(); gatt?.close() } catch (_: Exception) {}
                gatt = null
                cccdReady = false
                say("Desconectado.")
            }
        })
        log = TextView(this).apply { text = "Registro BLE:"; textSize = 13f }
        layout.addView(ScrollView(this).apply { addView(log) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(layout)
        adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    }

    private fun requestBlePermissions() {
        val needed = if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        val missing = needed.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 42) else scan()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 42 && grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) scan()
        else say("Faltan permisos Bluetooth. Actívalos en Ajustes.")
    }

    private fun scan() {
        if (!adapter.isEnabled) { say("Activa Bluetooth y vuelve a buscar."); return }
        scanner = adapter.bluetoothLeScanner
        target = null
        say("Buscando BMS BLE… espera hasta 15 segundos.")
        try {
            scanner?.startScan(scanCallback)
            android.os.Handler(mainLooper).postDelayed({
                try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
                if (target == null) say("Búsqueda terminada: no se encontró el BMS. Intenta de nuevo cerca de la batería.")
            }, 15000)
        } catch (e: Exception) { say("No se pudo buscar: ${e.message}") }
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val d = result.device
            val name = try { d.name ?: result.scanRecord?.deviceName ?: "" } catch (_: SecurityException) { "" }
            if (name.contains("BMS", true) || d.address.equals(knownAddress, true)) {
                target = d
                try { scanner?.stopScan(this) } catch (_: Exception) {}
                say("Encontrado: ${if (name.isBlank()) "BMS" else name} (${d.address}). Pulsa Conectar.")
            }
        }
        override fun onScanFailed(errorCode: Int) { say("Falló búsqueda BLE. Código $errorCode") }
    }

    private val callback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                say("Conectado (estado=$statusCode). Descubriendo servicios…")
                g.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                cccdReady = false
                say("Desconectado. Código $statusCode")
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
            if (statusCode != BluetoothGatt.GATT_SUCCESS) { say("Error leyendo servicios: $statusCode"); return }
            g.services.forEach { svc ->
                say("SERVICIO ${svc.uuid}")
                svc.characteristics.forEach { ch -> say("  CARACTERÍSTICA ${ch.uuid}; props=${ch.properties}") }
            }
            val svc = g.getService(serviceId)
            if (svc == null) { say("No aparece el servicio esperado 00002760…"); return }
            notifyChar = svc.characteristics.firstOrNull {
                (it.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0 ||
                (it.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0
            }
            writeChar = svc.characteristics.firstOrNull {
                (it.properties and BluetoothGattCharacteristic.PROPERTY_WRITE) != 0 ||
                (it.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0
            }
            val nc = notifyChar
            if (nc != null) {
                val localOk = try { g.setCharacteristicNotification(nc, true) } catch (e: Exception) {
                    say("Error activando notificación local: ${e.message}"); false
                }
                say("Notificación local habilitada=$localOk para ${nc.uuid}")
                val desc = nc.getDescriptor(cccdId)
                if (desc != null) {
                    try {
                        if (Build.VERSION.SDK_INT >= 33) {
                            val result = g.writeDescriptor(desc, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
                            say("Solicitud de escritura CCCD: $result")
                        } else {
                            @Suppress("DEPRECATION") desc.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                            @Suppress("DEPRECATION") val ok = g.writeDescriptor(desc)
                            say("Solicitud de escritura CCCD: $ok")
                        }
                    } catch (e: Exception) { say("Error configurando CCCD: ${e.message}") }
                } else say("La característica notify no tiene descriptor CCCD.")
            } else say("No se encontró característica notify/indicate.")
            say(if (writeChar != null) "Canal de escritura: ${writeChar!!.uuid}" else "No se encontró canal de escritura.")
        }

        override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, statusCode: Int) {
            if (descriptor.uuid == cccdId) cccdReady = statusCode == BluetoothGatt.GATT_SUCCESS
            say("Resultado descriptor CCCD: $statusCode (0=éxito); notificaciones listas=$cccdReady")
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, statusCode: Int) {
            say("Resultado escritura GATT: $statusCode (0=éxito). La escritura aceptada no garantiza respuesta del BMS.")
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            say("RX ${characteristic.uuid}: ${value.hex()}")
        }

        @Deprecated("Deprecated in Java")
        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            @Suppress("DEPRECATION") val value = characteristic.value ?: byteArrayOf()
            say("RX ${characteristic.uuid}: ${value.hex()}")
        }
    }

    private fun send(bytes: ByteArray) {
        val g = gatt ?: run { say("No estás conectado."); return }
        val ch = writeChar ?: run { say("No hay canal de escritura identificado."); return }
        if (notifyChar != null && !cccdReady) {
            say("AVISO: CCCD todavía no confirmó éxito. No envío para evitar una prueba ambigua.")
            return
        }
        try {
            say("TX ${ch.uuid}: ${bytes.hex()}")
            if (Build.VERSION.SDK_INT >= 33) {
                val type = if ((ch.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0)
                    BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                val result = g.writeCharacteristic(ch, bytes, type)
                say("Solicitud de envío: resultado=$result")
            } else {
                @Suppress("DEPRECATION") ch.value = bytes
                ch.writeType = if ((ch.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0)
                    BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                @Suppress("DEPRECATION") val ok = g.writeCharacteristic(ch)
                say("Solicitud de envío: aceptada=$ok")
            }
        } catch (e: Exception) { say("Error escribiendo: ${e.message}") }
    }

    private fun parseHex(input: String): ByteArray? {
        val cleaned = input.trim().replace(',', ' ').replace("0x", "", ignoreCase = true)
        if (cleaned.isEmpty()) return null
        val tokens = cleaned.split(Regex("\\s+"))
        if (tokens.any { it.isEmpty() || it.length > 2 || it.any { c -> c.digitToIntOrNull(16) == null } }) return null
        return try { tokens.map { it.toInt(16).toByte() }.toByteArray() } catch (_: Exception) { null }
    }

    private fun ByteArray.hex() = joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }

    override fun onDestroy() {
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
