# Nations BMS Reader — diagnóstico TX/RX automático

Esta versión usa el dispositivo BLE observado `BMS-508281060400331D`, servicio `00002760-08c2-11e1-9073-0e8ac72e1001`, y registra escrituras TX, notificaciones RX y resultado del descriptor CCCD.

## Cambio principal
Después de conectar, activar notificaciones y confirmar CCCD=0, el botón **AUTO: probar 2 tramas observadas** envía una sola vez cada una de las dos tramas que ya aparecieron en la captura previa:
- `DB DB 01 03 00 00 00 01 04`
- `DB DB 03 03 00 00 00 03 06`

Entre ambas hay 1,2 s. El registro muestra TX exacto, respuesta GATT de escritura, cada RX en hexadecimal y el total de paquetes/bytes. No interpreta arbitrariamente ningún byte como SOC: el formato debe confirmarse primero.

## Compilación
Java 17, Gradle 8.9, Android SDK platform 35 y build-tools 35.0.0. Ejecutar `gradle assembleDebug`; APK en `app/build/outputs/apk/debug/app-debug.apk`.
