# Nations BMS Reader — versión 0.2 (diagnóstico de SOC)

Esta versión corrige el descubrimiento GATT: intenta refrescar la caché Bluetooth oculta de Android antes de `discoverServices()`, enumera servicios y características, y busca exactamente el servicio Nations `00002760-08c2-11e1-9073-0e8ac72e1001` y la característica NOTIFY `...e0002`.

**No envía comandos al BMS.** La referencia técnica de Nations NS-BLE-1.0 indica que el estado se transmite mediante notificaciones. Cuando recibe una trama de estado conocida (`01 03 10 ...`), registra los bytes y muestra el byte SOC candidato; el formato debe confirmarse con una trama real de esta batería.

El registro debe mostrar: resultado de `refresh()`, servicios y características descubiertos, `CCCD completado: status=0`, y cualquier `NOTIFY (...)`. Si la característica exacta no aparece, el log deja constancia de ello en lugar de afirmar que está escuchando.

Compilar con GitHub Actions usando `.github/workflows/build-apk.yml`.
