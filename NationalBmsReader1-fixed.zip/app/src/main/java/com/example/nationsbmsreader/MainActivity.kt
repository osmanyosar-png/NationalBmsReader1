package com.example.nationsbmsreader

import android.Manifest
import android.app.Activity
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*
import java.util.UUID

/** Nations NS-BLE protocol test: connect, subscribe, listen for unsolicited packets, parse candidate SOC. */
class MainActivity : Activity() {
    private val serviceId = UUID.fromString("00002760-08c2-11e1-9073-0e8ac72e1001")
    private val writeId = UUID.fromString("00002760-08c2-11e1-9073-0e8ac72e0001")
    private val notifyId = UUID.fromString("00002760-08c2-11e1-9073-0e8ac72e0002")
    private val cccdId = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    private lateinit var status: TextView
    private lateinit var soc: TextView
    private lateinit var log: TextView
    private lateinit var adapter: BluetoothAdapter
    private var scanner: BluetoothLeScanner? = null
    private var gatt: BluetoothGatt? = null
    private var notifyChar: BluetoothGattCharacteristic? = null
    private var writeChar: BluetoothGattCharacteristic? = null
    private var scanning = false
    private var cacheRefreshResult: String = "no intentado"

    private fun ui(block: () -> Unit) = runOnUiThread(block)
    private fun say(s: String) { ui { status.text = s; log.append("\n$s\n") } }
    private fun logOnly(s: String) { ui { log.append("\n$s") } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 20, 24, 20) }
        layout.addView(TextView(this).apply { text = "Nations BMS Reader — diagnóstico BLE"; textSize = 22f })
        status = TextView(this).apply { text = "Listo. Pulsa Iniciar."; textSize = 16f }
        layout.addView(status)
        soc = TextView(this).apply { text = "SOC: esperando datos del BMS"; textSize = 26f }
        layout.addView(soc)
        layout.addView(Button(this).apply { text = "INICIAR: buscar, conectar y escuchar"; setOnClickListener { requestBlePermissions() } })
        layout.addView(Button(this).apply { text = "Desconectar"; setOnClickListener { disconnect() } })
        log = TextView(this).apply { text = "Registro BLE:"; textSize = 12f }
        layout.addView(ScrollView(this).apply { addView(log) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(layout)
        adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    }

    private fun requestBlePermissions() {
        val needed = if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        val missing = needed.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 42) else scan()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 42 && grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) scan()
        else say("Faltan permisos Bluetooth. Actívalos en Ajustes y vuelve a iniciar.")
    }

    private fun scan() {
        if (!adapter.isEnabled) { say("Activa Bluetooth y pulsa INICIAR otra vez."); return }
        try {
            scanner = adapter.bluetoothLeScanner
            if (scanning) scanner?.stopScan(scanCallback)
            scanning = true
            say("Buscando BMS-508281060400331D…")
            scanner?.startScan(scanCallback)
        } catch (e: Exception) { say("No se pudo iniciar búsqueda: ${e.message}") }
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val d = result.device
            val name = try { d.name ?: result.scanRecord?.deviceName ?: "" } catch (_: SecurityException) { "" }
            if (d.address.equals("53:62:10:0C:32:38", true) || name.contains("BMS-508281060400331D", true)) {
                try { scanner?.stopScan(this) } catch (_: Exception) {}
                scanning = false
                say("BMS encontrado: $name (${d.address}). Conectando automáticamente…")
                try { gatt?.close() } catch (_: Exception) {}
                gatt = d.connectGatt(this@MainActivity, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
            }
        }
        override fun onScanFailed(errorCode: Int) { scanning = false; say("Falló la búsqueda BLE. Código $errorCode") }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                // The saved HCI capture showed only Android's Generic Attribute service,
                // not Nations 0x2760. Force a fresh GATT database before discovery.
                cacheRefreshResult = refreshGattCache(g)
                say("Conectado. Caché GATT: $cacheRefreshResult. Descubriendo servicios reales…")
                val started = g.discoverServices()
                say("discoverServices() aceptado=$started")
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                say("BMS desconectado (estado $statusCode).")
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
            if (statusCode != BluetoothGatt.GATT_SUCCESS) { say("Error descubriendo servicios: $statusCode"); return }
            g.services.forEach { service ->
                say("Servicio descubierto: ${service.uuid}")
                service.characteristics.forEach { ch ->
                    say("  Característica: ${ch.uuid}; properties=0x${ch.properties.toString(16)}")
                    ch.descriptors.forEach { d -> say("    Descriptor: ${d.uuid}") }
                }
            }
            val svc = g.getService(serviceId)
            if (svc == null) {
                say("ERROR: tras refrescar caché no aparece Nations $serviceId. No se enviaron comandos.")
                return
            }
            val nc = svc.getCharacteristic(notifyId)
            if (nc == null) {
                say("ERROR: servicio Nations sí aparece, pero falta la característica exacta NOTIFY $notifyId. No se enviaron comandos.")
                return
            }
            notifyChar = nc
            writeChar = svc.getCharacteristic(writeId)
            say("Característica de notificación exacta encontrada: ${nc.uuid}; properties=0x${nc.properties.toString(16)}")
            if (writeChar != null) say("Característica de escritura encontrada: ${writeChar!!.uuid}; NO se enviarán comandos de prueba.")
            val local = g.setCharacteristicNotification(nc, true)
            say("Servicio Nations encontrado. Suscripción local=$local; activando notificaciones CCCD…")
            val desc = nc.getDescriptor(cccdId)
            if (desc == null) { say("No hay descriptor CCCD; no se pueden activar notificaciones."); return }
            try {
                if (Build.VERSION.SDK_INT >= 33) {
                    val result = g.writeDescriptor(desc, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
                    say("Solicitud CCCD enviada; resultado=$result")
                } else {
                    @Suppress("DEPRECATION") desc.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                    @Suppress("DEPRECATION") val ok = g.writeDescriptor(desc)
                    say("Solicitud CCCD enviada; aceptada=$ok")
                }
            } catch (e: Exception) { say("Error activando notificaciones: ${e.message}") }
        }

        override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, statusCode: Int) {
            say("CCCD completado: status=$statusCode.")
            if (statusCode == BluetoothGatt.GATT_SUCCESS) {
                say("SUSCRIPCIÓN CONFIRMADA. Escuchando datos de la característica Nations; no se envían comandos inventados.")
            } else {
                say("La suscripción CCCD falló; no se envían comandos.")
            }
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, statusCode: Int) {
            say("TX callback ${characteristic.uuid}: status=$statusCode")
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            handlePacket(value)
        }

        @Deprecated("Deprecated in Java")
        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            @Suppress("DEPRECATION") val v = characteristic.value ?: byteArrayOf()
            handlePacket(v)
        }
    }

    /** Clear Android's hidden GATT cache because the saved capture only showed Generic Attribute service. */
    private fun refreshGattCache(g: BluetoothGatt): String {
        return try {
            val method = g.javaClass.getMethod("refresh")
            val result = method.invoke(g) as? Boolean
            "refresh()=${result ?: "sin resultado"}"
        } catch (e: Exception) {
            "refresh() no disponible (${e.javaClass.simpleName})"
        }
    }

    private fun handlePacket(bytes: ByteArray) {
        if (bytes.isEmpty()) { logOnly("NOTIFY vacío"); return }
        val hex = bytes.joinToString(" ") { "%02X".format(it.toInt() and 0xff) }
        logOnly("NOTIFY (${bytes.size} bytes): $hex")
        // Published Nations NS-BLE-1.0 sample: 01 03 10 ...; SOC at zero-based offset 10.
        val b = bytes.map { it.toInt() and 0xff }
        if (b.size >= 11 && b[0] == 0x01 && b[1] == 0x03 && (b[2] == 0x10 || b[2] == 0x0c)) {
            val value = b[10]
            if (value in 0..100) {
                ui { soc.text = "SOC: $value% (paquete Nations detectado)" }
                logOnly("SOC candidato detectado en byte 10: $value%")
            } else logOnly("Paquete parecido a Nations, pero SOC fuera de rango: $value")
        } else {
            logOnly("Paquete recibido, formato SOC aún no reconocido.")
        }
    }

    private fun disconnect() {
        try { if (scanning) scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        scanning = false
        try { gatt?.disconnect(); gatt?.close() } catch (_: Exception) {}
        gatt = null
        say("Desconectado manualmente.")
    }

    override fun onDestroy() {
        try { if (scanning) scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
