# Nations BMS Reader — prueba SOC automática

Esta versión busca el dispositivo BMS-508281060400331D (MAC conocida), conecta automáticamente, activa notificaciones en el servicio Nations 00002760-08c2-11e1-9073-0e8ac72e1001 y escucha paquetes sin enviar comandos de sondeo.

El analizador prueba el formato documentado públicamente para Nations NS-BLE-1.0: paquete 01 03 10... con SOC en el desplazamiento 10. Es un candidato de protocolo, no una garantía de compatibilidad con todos los firmwares MUST. La app muestra el paquete bruto y etiqueta el SOC como candidato hasta validarlo contra los datos reales de la batería.

Compilar con JDK 17, Gradle 8.9, Android SDK platform 35 y build-tools 35.0.0. En GitHub Actions se compila con el workflow incluido.
