# Nations BMS Reader — prototipo BLE

Proyecto Android mínimo para escanear dispositivos BLE, conectarse al BMS, listar servicios/características, activar notificaciones y enviar dos consultas observadas en el registro del usuario.

## Importante
- Este prototipo todavía NO calcula ni muestra SOC.
- Primero hay que confirmar el protocolo y la respuesta real del BMS; no se debe inventar el porcentaje.
- Servicio esperado inicialmente: `00002760-08c2-11e1-9073-0e8ac72e1001`.
- Consultas de prueba: `01 03 00 00 00 01 04` y `03 03 00 00 00 03 06`.

## Compilación
JDK 17, Gradle 8.9, Android SDK platform 35 y build-tools 35.0.0. Ejecutar `gradle assembleDebug`. APK: `app/build/outputs/apk/debug/app-debug.apk`.
